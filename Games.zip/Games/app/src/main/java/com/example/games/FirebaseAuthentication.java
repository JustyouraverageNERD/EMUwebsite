package com.example.games;

import android.util.Log;
import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class FirebaseAuthentication {

    private static final String TAG = "FirebaseAuth";
    private static final FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static final FirebaseAuth auth = FirebaseAuth.getInstance();

    /**
     * Callback interface for authentication operations.
     */
    public interface AuthenticationCallback {
        void onSuccess(UserDetails userDetails);
        void onError(String errorMessage);
    }

    /**
     * Authenticates user with username and password by looking up email in Firestore
     * then signing in with Firebase Auth.
     *
     * @param username The username entered by the user
     * @param password The password entered by the user
     * @param callback Callback to handle success or failure
     */
    public static void loginWithUsername(@NonNull String username, @NonNull String password,
                                         @NonNull final AuthenticationCallback callback) {

        // Step 1: Query Firestore to find the user document with matching username
        db.collection("users")
                .whereEqualTo("username", username)
                .limit(1)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();

                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            // Found the user document
                            QueryDocumentSnapshot document = (QueryDocumentSnapshot) querySnapshot.getDocuments().get(0);
                            String email = document.getString("email");

                            if (email != null && !email.isEmpty()) {
                                // Step 2: Sign in with email and password
                                signInWithEmail(email, password, document, callback);
                            } else {
                                Log.e(TAG, "Email not found in user document");
                                callback.onError("User account configuration error. Please contact support.");
                            }
                        } else {
                            // Username not found
                            Log.w(TAG, "No user found with username: " + username);
                            callback.onError("Invalid username or password");
                        }
                    } else {
                        // Firestore query failed
                        Log.e(TAG, "Error querying Firestore", task.getException());
                        callback.onError("Network error. Please check your connection and try again.");
                    }
                });
    }

    /**
     * Signs in with email and password, then loads user details.
     */
    private static void signInWithEmail(@NonNull String email, @NonNull String password,
                                        @NonNull QueryDocumentSnapshot userDocument,
                                        @NonNull final AuthenticationCallback callback) {

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();

                        if (firebaseUser != null) {
                            Log.i(TAG, "Authentication successful for user: " + firebaseUser.getUid());

                            // Step 3: Create UserDetails object from Firestore document
                            UserDetails userDetails = createUserDetailsFromDocument(userDocument);

                            if (userDetails != null) {
                                callback.onSuccess(userDetails);
                            } else {
                                callback.onError("Error loading user data. Please try again.");
                            }
                        } else {
                            Log.e(TAG, "Firebase user is null after successful authentication");
                            callback.onError("Authentication error. Please try again.");
                        }
                    } else {
                        // Authentication failed
                        Log.e(TAG, "Authentication failed", task.getException());

                        String errorMessage = "Invalid username or password";
                        if (task.getException() != null) {
                            String exceptionMessage = task.getException().getMessage();
                            if (exceptionMessage != null) {
                                if (exceptionMessage.contains("password")) {
                                    errorMessage = "Invalid username or password";
                                } else if (exceptionMessage.contains("network")) {
                                    errorMessage = "Network error. Please check your connection.";
                                }
                            }
                        }
                        callback.onError(errorMessage);
                    }
                });
    }

    /**
     * Creates a UserDetails object from a Firestore document.
     */
    private static UserDetails createUserDetailsFromDocument(@NonNull QueryDocumentSnapshot document) {
        try {
            String username = document.getString("username");
            String userID = document.getId(); // Get the document ID as userID
            String email = document.getString("email");

            // Handle totalPoints - might be stored as Long or Integer
            int totalPoints = 0;
            Object pointsObj = document.get("totalPoints");
            if (pointsObj instanceof Long) {
                totalPoints = ((Long) pointsObj).intValue();
            } else if (pointsObj instanceof Integer) {
                totalPoints = (Integer) pointsObj;
            }

            // Validate required fields
            if (username == null || userID == null || email == null) {
                Log.e(TAG, "Missing required fields in user document");
                return null;
            }

            Log.i(TAG, "User details loaded - Username: " + username + ", UserID (Doc ID): " + userID + ", Points: " + totalPoints);
            return new UserDetails(username, userID, email, totalPoints);

        } catch (Exception e) {
            Log.e(TAG, "Error creating UserDetails from document", e);
            return null;
        }
    }

    /**
     * Alternative login method using email directly (if needed).
     */
    public static void loginWithEmail(@NonNull String email, @NonNull String password,
                                      @NonNull final AuthenticationCallback callback) {

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();

                        if (firebaseUser != null) {
                            // Load user details from Firestore
                            loadUserDetailsFromFirestore(firebaseUser.getUid(), callback);
                        } else {
                            callback.onError("Authentication error. Please try again.");
                        }
                    } else {
                        Log.e(TAG, "Email authentication failed", task.getException());
                        callback.onError("Invalid email or password");
                    }
                });
    }

    /**
     * Loads user details from Firestore using UID.
     */
    private static void loadUserDetailsFromFirestore(@NonNull String uid,
                                                     @NonNull final AuthenticationCallback callback) {

        db.collection("users")
                .whereEqualTo("uid", uid)
                .limit(1)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();

                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            QueryDocumentSnapshot document = (QueryDocumentSnapshot) querySnapshot.getDocuments().get(0);
                            UserDetails userDetails = createUserDetailsFromDocument(document);

                            if (userDetails != null) {
                                callback.onSuccess(userDetails);
                            } else {
                                callback.onError("Error loading user data. Please try again.");
                            }
                        } else {
                            Log.w(TAG, "User document not found for UID: " + uid);
                            callback.onError("User profile not found. Please contact support.");
                        }
                    } else {
                        Log.e(TAG, "Error loading user details", task.getException());
                        callback.onError("Error loading user data. Please try again.");
                    }
                });
    }

    /**
     * Signs out the current user.
     */
    public static void signOut() {
        auth.signOut();
        Log.i(TAG, "User signed out");
    }

    /**
     * Checks if a user is currently signed in.
     */
    public static boolean isUserSignedIn() {
        return auth.getCurrentUser() != null;
    }

    /**
     * Gets the current user's UID.
     */
    public static String getCurrentUserId() {
        FirebaseUser user = auth.getCurrentUser();
        return user != null ? user.getUid() : null;
    }
}