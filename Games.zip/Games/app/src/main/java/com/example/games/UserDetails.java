package com.example.games;

public class UserDetails {
    private String username;
    private String userID;
    private String email;
    private int totalPoints;

    public UserDetails(String username, String userID, String email, int totalPoints){
        this.username = username;
        this.userID = userID;
        this.email = email;
        this.totalPoints = totalPoints;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(int totalPoints) {
        this.totalPoints = totalPoints;
    }
}
