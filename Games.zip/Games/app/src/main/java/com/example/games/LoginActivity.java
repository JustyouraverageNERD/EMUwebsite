package com.example.games;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.games.FirebaseAuthentication;
import com.example.games.R;
import com.example.games.UserDetails;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton;
    private TextView createAccountPrompt, forgotPasswordPrompt;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeViews();
        setupClickListeners();

        // Check if user is already logged in
        if (FirebaseAuthentication.isUserSignedIn()) {
            navigateToCompletion();
        }
    }

    private void initializeViews() {
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountPrompt = findViewById(R.id.createAccountPrompt);
        forgotPasswordPrompt = findViewById(R.id.forgotPasswordPrompt);

        // Optional: Add a ProgressBar to your layout
        // progressBar = findViewById(R.id.progressBar);
    }

    private void setupClickListeners() {
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInput()) {
                    performLogin();
                }
            }
        });

        createAccountPrompt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        forgotPasswordPrompt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(LoginActivity.this, "Forgot Password - Coming Soon!", Toast.LENGTH_SHORT).show();
            }
        });

        forgotPasswordPrompt.setEnabled(false);
    }

    private boolean validateInput() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(username)) {
            usernameEditText.setError("Username is required");
            usernameEditText.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(password)) {
            passwordEditText.setError("Password is required");
            passwordEditText.requestFocus();
            return false;
        }

        if (password.length() < 6) {
            passwordEditText.setError("Password must be at least 6 characters");
            passwordEditText.requestFocus();
            return false;
        }

        return true;
    }

    private void performLogin() {
        String username = usernameEditText.getText().toString().trim();
        String password = md5(passwordEditText.getText().toString().trim());

        // Show loading state
        setLoadingState(true);

        // Authenticate with Firebase
        FirebaseAuthentication.loginWithUsername(username, password,
                new FirebaseAuthentication.AuthenticationCallback() {
                    @Override
                    public void onSuccess(UserDetails userDetails) {
                        // Hide loading state
                        setLoadingState(false);

                        // Show success message
                        Toast.makeText(LoginActivity.this,
                                "Welcome back, " + userDetails.getUsername() + "!",
                                Toast.LENGTH_SHORT).show();

                        // Pass user details to the next activity
                        navigateToCompletion(userDetails);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        // Hide loading state
                        setLoadingState(false);

                        // Show error message
                        Toast.makeText(LoginActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void setLoadingState(boolean isLoading) {
        loginButton.setEnabled(!isLoading);
        usernameEditText.setEnabled(!isLoading);
        passwordEditText.setEnabled(!isLoading);
        createAccountPrompt.setEnabled(!isLoading);

        if (progressBar != null) {
            progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        }

        loginButton.setText(isLoading ? "Logging in..." : "Login");
    }

    private void navigateToCompletion() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void navigateToCompletion(UserDetails userDetails) {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);

        // Pass user details to CompletionActivity
        intent.putExtra("username", userDetails.getUsername());
        intent.putExtra("userID", userDetails.getUserID());
        intent.putExtra("email", userDetails.getEmail());
        intent.putExtra("totalPoints", userDetails.getTotalPoints());

        startActivity(intent);
        finish();
    }

    public static String md5(final String s) {
        final String MD5 = "MD5";
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest.getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2) {
                    h = "0" + h;
                }
                hexString.append(h);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
}