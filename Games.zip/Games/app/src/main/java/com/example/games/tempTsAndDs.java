package com.example.games;

public class tempTsAndDs {
    /*
    * Agile:    An iterative development methodology focused on collaboration, self-organizing teams, and rapid adaptation to change;
      Alias:    An alternate name or label that refers to the same underlying entity;
      Build:    The process of compiling source code into a standalone, executable application;
      Cache:    A high-speed data storage layer that temporarily holds data, making future requests for that data faster;
      Class:    A blueprint or template for creating objects in object-oriented programming;
      Clone:    To create an exact duplicate of a repository, object, or system;
      Code:     Instructions written in a programming language that a computer can execute;
      Commit:   The process of saving changes to a repository in a version control system;
      Debug:    The process of identifying, analyzing, and removing errors or bugs from computer hardware or software;
      Deploy:   The process of installing software in its intended environment, making it ready for use;
      Design:   The process of defining the architecture, components, modules, interfaces, and data for a system to satisfy specified requirements;
      DevOps:   A set of practices that combines software development (Dev) and IT operations (Ops) to shorten the systems development life cycle;
      Drive:    A storage device that holds and retrieves digital data;
      Factor:   Short for refactor, the process of restructuring existing computer code without changing its external behavior;
      Frame:    A standardized division of a larger data unit, often used in networking or user interface design;
      Fuzz:     A software testing technique that involves providing invalid, unexpected, or random data to the inputs of a computer program;
      Hacker:   A person who uses their technical skills to gain unauthorized access to computer systems, sometimes with malicious intent;
      Issue:    A bug, defect, or enhancement request tracked within a project;
      Iterate:  To repeat a process or set of instructions, often with the goal of getting closer to a desired result;
      Kernel:   The core part of an operating system that manages the system's resources and provides a foundation for application programs;
      Logic:    The internal reasoning or structure of a program or system, dictating how it processes information;
      Merge:    The operation of combining multiple sets of changes into a unified whole, often in version control;
      Model:    A simplified representation of a system or process used for analysis, design, or understanding;
      Patch:    A small piece of software designed to update, fix, or improve a computer program or its supporting data;
      Pixel:    Short for picture element, the smallest physical point in a raster image or display;
      Query:    A request for data or information from a database or other data source;
      Queue:    A data structure that stores a collection of elements, typically using a First-In, First-Out (FIFO) order;
      Refine:   To improve a specification, design, or implementation through detail and correction;
      Route:    A defined path or sequence of operations for data or network traffic;
      Schema:   The structure defined in a formal language for all or part of a database;
      Scope:    The defined boundaries and extent of a project, feature, or variable's visibility;
      Script:   A program or sequence of instructions that is executed without being compiled;
      Server:   A computer program or device that provides a service to another computer program and its user, known as the client;
      Stack:    A specialized computer memory area that stores temporary data, often using a Last-In, First-Out (LIFO) order;
      Test:     The process of evaluating a system or its component(s) with the intent to find whether it satisfies the specified requirements;
      Thread:   A single sequence of programmed instructions that can be managed independently by a scheduler;
      Token:    A sequence of characters having a collective meaning, often used in parsing or security;
      Trace:    A chronological record of the sequence of statements executed by a program;
      UML:      Short for Unified Modeling Language, a standardized general-purpose modeling language in the field of object-oriented software engineering;
      Unit:     The smallest testable part of an application, such as a class or a function;
    *
    * */
}
