package com.example.games;

import android.util.Log;
import androidx.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class FirebaseAuthHelper {

    private static final String TAG = "FirebaseAuthHelper";
    private static final FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static final FirebaseAuth auth = FirebaseAuth.getInstance();

    public static String userID;

    /**
     * Callback interface for authentication operations.
     */
    public interface AuthCallback {
        void onSuccess(String userId);
        void onError(Exception e);
    }

    /**
     * Callback interface for Firestore data retrieval.
     */
    public interface FirestoreCallback {
        void onCallback(String data);
        void onError(Exception e);
    }

    /**
     * Signs in a user with email and password.
     * @param email User's email address
     * @param password User's password
     * @param callback Callback to handle the result
     */
    public static void signInWithEmail(@NonNull String email, @NonNull String password,
                                       @NonNull final AuthCallback callback) {
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = auth.getCurrentUser();
                        if (user != null) {
                            Log.i(TAG, "Sign in successful for user: " + user.getUid());
                            userID = user.getUid();
                            callback.onSuccess(user.getUid());
                        } else {
                            callback.onError(new Exception("Authentication succeeded but user is null"));
                        }
                    } else {
                        Log.e(TAG, "Sign in failed", task.getException());
                        callback.onError(task.getException());
                    }
                });
    }

    public static String getUserID(){
        return userID;
    }

    /**
     * Creates a new user account with email and password.
     * @param email User's email address
     * @param password User's password
     * @param callback Callback to handle the result
     */
    public static void signUpWithEmail(@NonNull String email, @NonNull String password,
                                       @NonNull final AuthCallback callback) {
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = auth.getCurrentUser();
                        if (user != null) {
                            Log.i(TAG, "Sign up successful for user: " + user.getUid());
                            callback.onSuccess(user.getUid());
                        } else {
                            callback.onError(new Exception("User creation succeeded but user is null"));
                        }
                    } else {
                        Log.e(TAG, "Sign up failed", task.getException());
                        callback.onError(task.getException());
                    }
                });
    }

    /**
     * Signs out the currently authenticated user.
     */
    public static void signOut() {
        auth.signOut();
        Log.i(TAG, "User signed out");
    }

    /**
     * Gets the currently authenticated user's UID.
     * @return The UID of the current user, or null if no user is signed in
     */
    public static String getCurrentUserId() {
        FirebaseUser currentUser = auth.getCurrentUser();
        return currentUser != null ? currentUser.getUid() : null;
    }

    /**
     * Checks if a user is currently authenticated.
     * @return true if a user is signed in, false otherwise
     */
    public static boolean isUserSignedIn() {
        return auth.getCurrentUser() != null;
    }

    /**
     * Gets the currently authenticated user.
     * @return The current FirebaseUser, or null if no user is signed in
     */
    public static FirebaseUser getCurrentUser() {
        return auth.getCurrentUser();
    }

    /**
     * Loads data from the user's Firestore document.
     * @param fieldName The field name to retrieve from the document
     * @param callback The callback to be invoked with the result
     */
    public static void loadUserData(@NonNull String fieldName,
                                    @NonNull final FirestoreCallback callback) {
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser == null) {
            String errorMessage = "No authenticated user found.";
            Log.e(TAG, errorMessage);
            callback.onError(new Exception(errorMessage));
            return;
        }

        String userUid = currentUser.getUid();

        db.collection("users")
                .whereEqualTo("uid", userUid)
                .limit(1)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();

                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            QueryDocumentSnapshot document = (QueryDocumentSnapshot) querySnapshot.getDocuments().get(0);
                            String data = document.getString(fieldName);

                            if (data != null && !data.isEmpty()) {
                                Log.i(TAG, fieldName + " found: " + data);
                                callback.onCallback(data);
                            } else {
                                String errorMessage = fieldName + " field is null or empty in the document.";
                                Log.e(TAG, errorMessage);
                                callback.onError(new Exception(errorMessage));
                            }
                        } else {
                            String errorMessage = "User document not found in Firestore for UID: " + userUid;
                            Log.w(TAG, errorMessage);
                            callback.onError(new Exception(errorMessage));
                        }
                    } else {
                        Log.e(TAG, "Error querying Firestore.", task.getException());
                        callback.onError(task.getException());
                    }
                });
    }

    /**
     * Loads the username for the currently authenticated user.
     * @param callback The callback to be invoked with the result
     */
    public static void loadUsername(@NonNull final FirestoreCallback callback) {
        loadUserData("username", callback);
    }

    /**
     * Sends a password reset email to the specified email address.
     * @param email The email address to send the reset link to
     * @param callback Callback to handle the result
     */
    public static void sendPasswordResetEmail(@NonNull String email,
                                              @NonNull final AuthCallback callback) {
        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Log.i(TAG, "Password reset email sent to: " + email);
                        callback.onSuccess(email);
                    } else {
                        Log.e(TAG, "Failed to send password reset email", task.getException());
                        callback.onError(task.getException());
                    }
                });
    }
}